#ifndef PARAMS_H
#define PARAMS_H

// relevant systemwide parameters should go here

/* GUI parameters */
#define WINDOW_HEIGHT         600
#define WINDOW_WIDTH          600
#define WINDOW_Y              100
#define WINDOW_X              400
#define ADD_AMT_INIT         0.1f

/* Colors */
#define RED         {1.0f, 0.0f, 0.0f}
#define GREEN       {0.0f, 1.0f, 0.0f}
#define BLUE        {0.0f, 0.0f, 1.0f}
#define YELLOW      {0.5f, 0.5f, 0.0f}
#define CYAN        {0.0f, 0.5f, 0.5f}
#define MAGENTA     {0.5f, 0.0f, 0.5f}
#define WHITE       {0.33f, 0.33f, 0.33f}
#define ALL_COLORS  {RED, GREEN, BLUE, YELLOW, CYAN, MAGENTA, WHITE}

/* Grid parameters */
#define CELLS_Y    120
#define CELLS_X    120
#define NUM_FLUIDS   7

/* Fluid parameters */
#define VORTICITY    1.0
#define VISCOSITY   0.00
#define DIFFUSION      0
#define DISSIPATION 0.01

/* Simulation parameters */
#define NUM_ITER              1
#define DT                 0.01
#define CONFINE_VORTICITY false

/* Computed */
#define num_cells (CELLS_Y * CELLS_X)

/* Functions */
inline int idx2d(int y, int x) { return y * CELLS_X + x; }

#endif
