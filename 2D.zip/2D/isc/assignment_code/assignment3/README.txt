6.837 Final Project
Grid-based fluid simulator
