#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#include "Fluid.h"
#include <math.h>
// #include "Image.hpp"
#define PI 3.14159265
using namespace std;

int window_height = WINDOW_HEIGHT;
int window_width = WINDOW_WIDTH;
int current_fluid;
Fluid fluid;

float add_amount;
double cr, cg, cb, alpha;
// float fluid_colors[3];
float fluid_colors[NUM_FLUIDS][3];
int frame_num = 0;


void init(void) {
    glClearColor(0.0, 0.0, 0.0, 0.0);
    cr = 0.7;
    cg = 0.9;
    cb = 0.3;
    alpha = 0.03;

    float colors[7][3] = ALL_COLORS;
    for (int i = 0; i < NUM_FLUIDS; ++i)
        memcpy(fluid_colors[i], colors[i], sizeof(colors[i]));
    // memcpy(fluid_colors, colors[1], sizeof(colors[1]));

    add_amount = ADD_AMT_INIT * max(CELLS_X, CELLS_Y);
    current_fluid = 0;

    fluid.init();

    // add force in a circle
    // int radius = 30;
    // for (int x = -radius; x <= radius; ++x) {
    //   int y = sqrt(radius*radius-x*x) + 0.5;
    //   fluid.add_U_y_force_at(60+y, 60+x, 30);
    //   fluid.add_U_x_force_at(60+y, 60+x, 30);
    //   fluid.add_U_y_force_at(60-y, 60+x, 30);
    //   fluid.add_U_x_force_at(60-y, 60+x, 30);
    //   fluid.add_source_at(60+y, 60+x, current_fluid, add_amount);
    //   fluid.add_source_at(60-y, 60+x, current_fluid, add_amount);
    // }

    // change velocity field to u(x,y) = (1,0) and add source along vertical line x=60
    for (int y = 0; y < CELLS_Y; ++y) {
        for (int x = 0; x < CELLS_X; ++x) {
          // fluid.add_U_y_force_at(y, x, 0.1*x);
          // fluid.add_U_x_force_at(y, x, -0.1*y);
          fluid.add_U_y_force_at(y, x, y);
          fluid.add_U_x_force_at(y, x, x);
          // fluid.add_U_y_force_at(y, x, sin(2*PI*x));
          // fluid.add_U_x_force_at(y, x, sin(2*PI*y));
        }
    }
    for (int y = 20; y < CELLS_Y-20; ++y) {
      for (int x = 20; x < CELLS_X-20; ++x) {
        if (x > CELLS_X/2) {fluid.add_source_at(y, x, current_fluid, add_amount);} // red
        else {fluid.add_source_at(y, x, current_fluid+1, add_amount);} //blue
      }
    }

}

void display(void) {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glPushMatrix();

    for (int y = 0; y < CELLS_Y; ++y) {
        for (int x = 0; x < CELLS_X; ++x) {
            cr = 0.0f; cg = 0.0f; cb = 0.0f;
            for (int i = 0; i < NUM_FLUIDS; i++) {
              cr += fluid_colors[i][0] * fluid.S_at(y, x, i);
              cg += fluid_colors[i][1] * fluid.S_at(y, x, i);
              cb += fluid_colors[i][2] * fluid.S_at(y, x, i);
            }
            glColor4f(cr, cg, cb, alpha);
            glRectf((x - 1.0f) * 2.0f / (CELLS_X - 2) - 1.0f, (y - 0.5f) * 2.0f / (CELLS_Y - 2) - 1.0f,
                    (x + 1.0f) * 2.0f / (CELLS_X - 2) - 1.0f, (y + 0.5f) * 2.0f / (CELLS_Y - 2) - 1.0f);
        }
    }

    glFlush();
    glutSwapBuffers();
}

void idle(void) {
    fluid.step();
    glutPostRedisplay();
}

int main(int argc, char* argv[]) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(window_width, window_height);
    glutInitWindowPosition(WINDOW_X, WINDOW_Y);
    glutCreateWindow("Unstable Fluids");

    init();

    glutDisplayFunc(display);
    glutIdleFunc(idle);

    glutMainLoop();

    return 0;
}
